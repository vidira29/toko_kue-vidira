<!-- footer -->
<div class="footer">
  <div class="container-fluid">
    <div class="row">
      <div class="col-xs-3 text-white">
        <img src="logo_vidira.png">
        <p style="padding-left: 1.5vw;margin-top: 8px; font-family: Eras Demi ITC; font-size: 17px">
        Toko Kue Online VIDIRA BAKERY
      Toko Kue yang menyediakan berbagai macam kue dari kue ulang tahun,kue basah dan kue kering. Semua produk yang di jual di sini terjamin kualitasnya. Kunjungilah Toko Kue Kami
    Alamat: Jl. Kol. Barlian No.167 Saung Naga, Sumatera Selatan
    No.hp : 082377431817</p>
       
      </div>
      
      <div class="col-xs-3 col-xs-offset-1 text-white">
        
      </div>
      
      <div class="col-xs-3 col-xs-offset-1 text-white">
      <h3 style="font-family:Cooper Std Black">Komentar </h3>
      <hr>
      <br>
        <form action="./proses/komentar.php" method="post" role="form">
          <div class="form-group">
            <label for="nama">Nama : </label>
            <input type="text" class="form-control" name="nama" placeholder="Nama">
          </div>
          <div class="form-group">
            <label for="email">Email : </label>
            <input type="text" class="form-control" name="email" placeholder="Email">
          </div>
          <div class="form-group">
            <label for="pesan">Pesan : </label>
            <textarea class="form-control" name="pesan" placeholder="Masukkan pesan "></textarea>
          </div>
          <button type="submit" class="btn btn-primary">Kirim</button>
        </form>
      </div>

    </div>
    <div class="row" id="cpy">
      <div class="col-xs-11">
        <p style="color : white; text-align: center;">@BATURAJA,SUMATERA SELATAN | TOKO VIDIRA BAKERY</p>
      </div>
    </div>
  </div>
<!-- end of footer -->