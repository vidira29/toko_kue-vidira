<h2>Selamat datang Adminitrator</h2>
<pre><?php print_r($_SESSION); ?></pre>